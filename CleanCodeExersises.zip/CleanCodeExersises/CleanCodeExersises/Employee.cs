﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CleanCodeExersises
{
    public class Employee
    {
        public int Age;
        public int YearsEmployed;
        public bool IsRetired;
    }
}
